<?php

$servername = "localhost";
$username = "litsurea_ap";
$password = "Ajal@7015";
$database = "litsurea_ap";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (mysqli_connect_errno()) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>

<?php
// Replace the placeholders with your actual database credentials
$db_host = 'localhost';
$db_username = 'socialsm_litsureacademy';
$db_password = 'socialsm_litsureacademy';
$db_name = 'socialsm_litsureacademy';

// Include the configuration file to get database credentials
@include 'config.php';

// Start the session
session_start();

// Check if the admin is logged in, if not, redirect to the login page
if (!isset($_SESSION['admin_name'])) {
   header('location:login_form.php');
   exit(); // It's good practice to add an exit() after header() to prevent further execution
}

// Establish a database connection
$connection = mysqli_connect($db_host, $db_username, $db_password, $db_name);

// Check if the connection was successful
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch user details from the 'users' table
$query = "SELECT * FROM home";
$result = mysqli_query($connection, $query);

?>

<!DOCTYPE html>
<html>
<head>
    <title>User Details</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>User Details</h1>

    <!-- Display the user details in an HTML table -->
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['phone']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Reset default margin and padding */
        body, html {
            margin: 0;
            padding: 0;
        }

        /* Set full-screen height */
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-color: #f4f4f4;
        }

        /* Your existing styles ... */
        .feature-box {
            width: 80%;
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            margin: 20px;
            text-align: left;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .feature-box h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .feature-box p {
            font-size: 16px;
            line-height: 1.5;
        }

        /* Remove underline from links */
        .course-card {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body>
    <div class="feature-box">
        <a href="user_page.php" class="course-card">
            <div class="course-card-content">
                <h3>SET ENGLISH PAPER 2 COACHING</h3>
                <p>Enroll now and enhance your English skills for SET Paper 2.</p>
            </div>
        </a>
    </div>

    <div class="feature-box">
        <a href="user_pages.php" class="course-card">
            <div class="course-card-content">
                <h3>SET GENERAL PAPER 1 COACHING</h3>
                <p>Join our coaching to excel in SET General Paper 1.</p>
            </div>
        </a>
    </div>
    
    <div class="feature-box">
        <a href="https://docs.google.com/forms/d/e/1FAIpQLSfA9xxmFdkXVnWj0D06GZHi8OUKqpaxYm_r7aiq49-dlof-hA/viewform?usp=sf_link" class="course-card">
            <div class="course-card-content">
                <h3>PRACTICE MCQ</h3>
            </div>
        </a>
    </div>
</body>
</html>

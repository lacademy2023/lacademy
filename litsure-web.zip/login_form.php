<?php
ob_start(); // Start output buffering

// Set the session timeout to 30 minutes (1800 seconds) before starting the session
ini_set('session.gc_maxlifetime', 1800);
session_set_cookie_params(1800);

session_start();

// Include the config.php file (make sure it doesn't produce any output)
@include 'config.php'; // Assuming you've removed the "Connected successfully!" message from config.php

$error = array();

if (isset($_POST['submit'])) {
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $pass = isset($_POST['password']) ? $_POST['password'] : '';

    // Sanitize user inputs to prevent SQL injection (better to use prepared statements)
    $email = mysqli_real_escape_string($conn, $email);
    $pass = mysqli_real_escape_string($conn, $pass);

    $select = "SELECT * FROM home WHERE email = '$email' AND password = '$pass'";
    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
        if ($row['user_type'] == 'admin') {
            $_SESSION['admin_name'] = $row['name'];
            $_SESSION['last_activity'] = time(); // Set the user's last activity timestamp
            header('location: admin_page.php');
            exit;
        } elseif ($row['user_type'] == 'user') {
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['last_activity'] = time(); // Set the user's last activity timestamp
            header('location: user_access.php');
            exit;
        }
    } else {
        $error[] = 'Incorrect email or password!';
    }
}

// Automatic Logout - Check the user's last activity and log them out if the session has expired
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    session_unset(); // Clear all session variables
    session_destroy(); // Destroy the session
    header('Location: login_form.php'); // Redirect to the login page after automatic logout
    exit();
} else {
    $_SESSION['last_activity'] = time(); // Update the last activity timestamp
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>login now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         }
      }
      ?>
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
      <input type="submit" name="submit" value="login now" class="form-btn">
      <p>don't have an account? <a href="register_form.php">register now</a></p>
   </form>

</div>

</body>
</html>
